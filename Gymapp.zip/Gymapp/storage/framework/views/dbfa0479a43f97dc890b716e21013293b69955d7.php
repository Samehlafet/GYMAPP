<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                

                
          
</div>

<div class="row">
<div class="col-lg-12" style="text-align: center">
<div >
<h2> CRUD</h2>
</div>
<br/>
</div>
</div>
<div class="row">
<div class="col-lg-12 margin-tb">
<div class="pull-right">
<a href="javascript:void(0)" class="btn btn-success mb-2" id="new-adherent" data-toggle="modal">New Adherent</a>
</div>
</div>
</div>
<br/>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<p id="msg"><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<table class="table table-bordered">
<tr>
<th>ID</th>
<th>Nom</th>
<th>Prenom</th>
<th>Email</th>
<th>Type</th>
<th width="280px">Action</th>
</tr>

<?php $__currentLoopData = $adherents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adherent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="adherent_id_<?php echo e($adherent->id); ?>">
<td><?php echo e($adherent->id); ?></td>
<td><?php echo e($adherent->nom); ?></td>
<td><?php echo e($adherent->prenom); ?></td>
<td><?php echo e($adherent->email); ?></td>
<td><?php echo e($adherent->type); ?></td>
<td> 
<form action="<?php echo e(route('adherents.destroy',$adherent->id)); ?>" method="POST">
<a class="btn btn-info" id="show-adherent" data-toggle="modal" data-id="<?php echo e($adherent); ?>" >Show</a>
<a href="javascript:void(0)" class="btn btn-success" id="edit-adherent" data-toggle="modal" data-id="<?php echo e($adherent->id); ?>">Edit </a>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<a id="delete-adherent" data-id="<?php echo e($adherent->id); ?>" class="btn btn-danger delete-user">Delete</a></td>
</form>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php echo $adherents->links(); ?>

<!-- Add and Edit adherent modal -->
<div class="modal fade" id="crud-modal" aria-hidden="true" >
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title" id="adherentCrudModal"></h4>
</div>
<div class="modal-body">
<form name="custForm" action="<?php echo e(route('adherents.index')); ?>" method="POST">
<input type="hidden" name="cust_id" id="cust_id" >
<?php echo csrf_field(); ?>
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
<strong>Nom:</strong>
<input type="text" name="nom" id="nom" class="form-control" placeholder="Nom" onchange="validate()" >
</div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
<strong>Prenom:</strong>
<input type="text" name="prenom" id="prenom" class="form-control" placeholder="Prenom" onchange="validate()">
</div>
</div>

<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
<strong>Email:</strong>
<input type="text" name="email" id="email" class="form-control" placeholder="Email" onchange="validate()">
</div>
</div>

<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
<strong>Type:</strong>
<input type="text" name="type" id="type" class="form-control" placeholder="Type" onchange="validate()">
</div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12 text-center">
<button adherent="submit" id="btn-save" name="btnsave" class="btn btn-primary" disbaled >Submit</button>
<a href="<?php echo e(route('adherents.index')); ?>" class="btn btn-danger">Cancel</a>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<!-- Show adherent modal -->
<div class="modal fade" id="crud-modal-show" aria-hidden="true" >
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title" id="adherentCrudModal-show"></h4>
</div>
<div class="modal-body">
<div class="row">
<div class="col-xs-2 col-sm-2 col-md-2"></div>
<div class="col-xs-10 col-sm-10 col-md-10 ">
<?php if(isset($adherent->nom)): ?>

<table>
<tr><td><strong>Nom:</strong></td><td id="nomshow"><?php echo e($adherent->nom); ?></td></tr>
<tr><td><strong>Prenom:</strong></td><td id="prenomshow"><?php echo e($adherent->prenom); ?></td></tr>
<tr><td><strong>Email:</strong></td><td id="emailshow"><?php echo e($adherent->email); ?></td></tr>
<tr><td><strong>Type:</strong></td><td id="typeshow"><?php echo e($adherent->type); ?></td></tr>
<tr><td colspan="2" style="text-align: right "><a href="<?php echo e(route('adherents.index')); ?>" class="btn btn-danger">OK</a> </td></tr>
</table>
<?php endif; ?>
</div>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<script>
error=false

function validate()
{
	if(document.custForm.nom.value !='' && document.custForm.prenom.value !='' && document.custForm.email.value !='' && document.custForm.type.value !='')
	    document.custForm.btnsave.disabled=false
	else
		document.custForm.btnsave.disabled=true
}
</script>
<?php echo $__env->make('adherents.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gymapp\resources\views/adherents/index.blade.php ENDPATH**/ ?>