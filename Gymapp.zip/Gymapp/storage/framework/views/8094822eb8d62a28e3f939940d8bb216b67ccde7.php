

<?php $__env->startSection('content'); ?>
<div class="container">

<h1>Typeeeeee </h1>





</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gymapp\resources\views/type.blade.php ENDPATH**/ ?>