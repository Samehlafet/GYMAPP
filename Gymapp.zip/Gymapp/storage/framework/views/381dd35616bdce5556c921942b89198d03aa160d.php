

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                

                
          
</div>

<div class="row">
<div class="col-lg-12" style="text-align: center">
<div >
<h2>CRUD </h2>
</div>
<br/>
</div>
</div>
<div class="row">
<div class="col-lg-12 margin-tb">
<div class="pull-right">
<a href="javascript:void(0)" class="btn btn-success mb-2" id="new-entraineur" data-toggle="modal">New Entraineur</a>
</div>
</div>
</div>
<br/>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
<p id="msg"><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<table class="table table-bordered">
<tr>
<th>ID</th>
<th>Nom</th>
<th>Prenom</th>
<th>Email</th>
<th>Type</th>
<th width="280px">Action</th>
</tr>

<?php $__currentLoopData = $entraineurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entraineur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="entraineur_id_<?php echo e($entraineur->id); ?>">
<td><?php echo e($entraineur->id); ?></td>
<td><?php echo e($entraineur->nom); ?></td>
<td><?php echo e($entraineur->prenom); ?></td>
<td><?php echo e($entraineur->email); ?></td>
<td><?php echo e($entraineur->type->name); ?></td>
<td> 
<form action="<?php echo e(route('entraineurs.destroy',$entraineur->id)); ?>" method="POST">
<a class="btn btn-info" id="show-entraineur" data-toggle="modal" data-id="<?php echo e($entraineur); ?>" >Show</a>
<a href="javascript:void(0)" class="btn btn-success" id="edit-entraineur" data-toggle="modal" data-id="<?php echo e($entraineur->id); ?>">Edit </a>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<a id="delete-entraineur" data-id="<?php echo e($entraineur->id); ?>" class="btn btn-danger delete-user">Delete</a></td>
</form>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php echo $entraineurs->links(); ?>

<!-- Add and Edit entraineur modal -->
<div class="modal fade" id="crud-modal" aria-hidden="true" >
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title" id="entraineurCrudModal"></h4>
</div>
<div class="modal-body">
<form name="custForm" action="<?php echo e(route('entraineurs.index')); ?>" method="POST">
<input type="hidden" name="cust_id" id="cust_id" >
<?php echo csrf_field(); ?>
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
<strong>Nom:</strong>
<input type="text" name="nom" id="name" class="form-control" placeholder="Nom" onchange="validate()" >
</div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
<strong>Prenom:</strong>
<input type="text" name="prenom" id="price" class="form-control" placeholder="Prenom" onchange="validate()">
</div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
<strong>Email:</strong>
<input type="text" name="email" id="email" class="form-control" placeholder="Email" onchange="validate()">
</div>
</div>
<div class="col-xs-12 col-sm-12 col-md-12">

<div class="form-group">
	<strong>Type</strong>
	
	<select name="type_id" id="myselect">
	<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value='<?php echo e($type->id); ?>'><?php echo e($type->name); ?></option>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
<div class="col-xs-12 col-sm-12 col-md-12 text-center">
<button type="submit" id="btn-save" name="btnsave" class="btn btn-primary" disbaled >Submit</button>
<a href="<?php echo e(route('entraineurs.index')); ?>" class="btn btn-danger">Cancel</a>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<!-- Show entraineur modal -->
<div class="modal fade" id="crud-modal-show" aria-hidden="true" >
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title" id="entraineurCrudModal-show"></h4>
</div>
<div class="modal-body">
<div class="row">
<div class="col-xs-2 col-sm-2 col-md-2"></div>
<div class="col-xs-10 col-sm-10 col-md-10 ">
<?php if(isset($entraineur->nom)): ?>

<table>
<tr><td><strong>Nom:</strong></td><td id="nomshow"><?php echo e($entraineur->nom); ?></td></tr>
<tr><td><strong>Prenom:</strong></td><td id="prenomshow"><?php echo e($entraineur->prenom); ?></td></tr>
<tr><td><strong>Email:</strong></td><td id="emailshow"><?php echo e($entraineur->email); ?></td></tr>
<tr><td><strong>Type_id:</strong></td><td id="type_idshow"><?php echo e($entraineur->type_id); ?></td></tr>
<tr><td colspan="2" style="text-align: right "><a href="<?php echo e(route('entraineurs.index')); ?>" class="btn btn-danger">OK</a> </td></tr>
</table>
<?php endif; ?>
</div>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<script>
error=false

function validate()
{
	if(document.custForm.nom.value !='' && document.custForm.prenom.value !=''&& document.custForm.email.value !='')
	    document.custForm.btnsave.disabled=false
	else
		document.custForm.btnsave.disabled=true
}
</script>
<?php echo $__env->make('entraineurs.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gymapp\resources\views/entraineurs/index.blade.php ENDPATH**/ ?>